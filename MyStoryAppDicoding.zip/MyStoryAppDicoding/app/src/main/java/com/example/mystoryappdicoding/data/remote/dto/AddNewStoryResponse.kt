package com.example.mystoryappdicoding.data.remote.dto

data class AddNewStoryResponse(
    val error: Boolean,
    val message: String
)