package com.example.mystoryappdicoding.data.remote.dto

data class LoginRequest(
    val email: String,
    val password: String
)